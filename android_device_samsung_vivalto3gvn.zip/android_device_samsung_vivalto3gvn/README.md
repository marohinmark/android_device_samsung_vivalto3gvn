Device configuration for Samsung Galaxy V SM-G313HZ (vivalto3gvn)
