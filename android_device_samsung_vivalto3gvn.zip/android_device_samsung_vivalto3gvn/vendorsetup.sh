for targetBuildVariant in eng user userdebug
do
    add_lunch_combo lineage_vivalto3gvn-${targetBuildVariant}
done
